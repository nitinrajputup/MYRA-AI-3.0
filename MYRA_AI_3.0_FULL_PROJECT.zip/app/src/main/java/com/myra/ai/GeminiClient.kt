package com.myra.ai
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
class GeminiClient {
    companion object {
        suspend fun ask(key:String,prompt:String):String=withContext(Dispatchers.IO){
            if(key.isBlank()) return@withContext "Error: Settings mein Gemini API key save karein."
            try {
                val payload=JSONObject().put("contents",JSONArray().put(JSONObject().put("parts",JSONArray().put(JSONObject().put("text",prompt))))).put("generationConfig",JSONObject().put("maxOutputTokens",1024)).toString()
                val req=Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent").addHeader("x-goog-api-key",key.trim()).addHeader("Content-Type","application/json").post(payload.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
                OkHttpClient.Builder().connectTimeout(20,TimeUnit.SECONDS).readTimeout(45,TimeUnit.SECONDS).build().newCall(req).execute().use{r->
                    val raw=r.body?.string().orEmpty()
                    if(!r.isSuccessful){val detail=runCatching{JSONObject(raw).optJSONObject("error")?.optString("message")}.getOrNull().orEmpty();return@withContext "Error ${r.code}: ${detail.ifBlank{raw.take(400)}}"}
                    JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text") ?: "No text in Gemini response"
                }
            }catch(e:Exception){"Error: ${e.message}"}
        }
    }
}
