package com.myra.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if(it==TextToSpeech.SUCCESS) tts?.language=Locale("hi","IN") }
        val prefs=getSharedPreferences("myra3",MODE_PRIVATE)
        setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Color.Cyan,background=Color(0xFF05060A),surface=Color(0xFF111521))) {
            MyraHome(prefs, onSpeak={tts?.speak(it,TextToSpeech.QUEUE_FLUSH,null,"myra")}, onOpenApp={openApp(it)})
        } }
    }
    private fun openApp(command:String) {
        val target=when(command.lowercase()) {
            "youtube"->"com.google.android.youtube"; "instagram"->"com.instagram.android"; "whatsapp"->"com.whatsapp"; "facebook"->"com.facebook.katana"; "chatgpt"->"com.openai.chatgpt"; "gemini"->"com.google.android.apps.bard"
            else->command
        }
        val launch=packageManager.getLaunchIntentForPackage(target)
        if(launch!=null) startActivity(launch) else startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(command))))
    }
    override fun onDestroy(){tts?.shutdown();super.onDestroy()}
}

@Composable
fun MyraHome(prefs:android.content.SharedPreferences,onSpeak:(String)->Unit,onOpenApp:(String)->Unit) {
    var tab by remember { mutableStateOf("Home") }; var api by remember { mutableStateOf(prefs.getString("gemini_key","") ?: "") }
    var text by remember { mutableStateOf("") }; var answer by remember { mutableStateOf("Namaste! Main MYRA hoon. Ji boss!") }
    var busy by remember { mutableStateOf(false) }; val chats=remember{mutableStateListOf<Pair<String,String>>()}; val scope=rememberCoroutineScope()
    val voice=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){ r->
        val spoken=r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if(!spoken.isNullOrBlank()){text=spoken; if(spoken.lowercase().startsWith("open ")) onOpenApp(spoken.substringAfter("open ").trim())}
    }
    Column(Modifier.fillMaxSize().background(Color(0xFF05060A)).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
            Text("MYRA AI 3.0",color=Color.Cyan,fontSize=23.sp)
            TextButton(onClick={tab=if(tab=="Settings")"Home" else "Settings"}){Text("⚙ SETTINGS",color=Color.White)}
        }
        if(tab=="Settings"){
            Text("Gemini + Voice Settings",color=Color.Cyan,fontSize=20.sp)
            OutlinedTextField(api,{api=it},label={Text("Gemini API Key")},modifier=Modifier.fillMaxWidth())
            Button(onClick={prefs.edit().putString("gemini_key",api.trim()).apply();answer="API key saved";onSpeak("API key save ho gayi")}){Text("SAVE KEY")}
            Text("Wake word: Android background microphone restrictions ke karan explicit service start + notification/permission chahiye.",color=Color.LightGray)
            Text("Phone control: Accessibility settings mein MYRA service manually enable karni hogi.",color=Color.LightGray)
        } else {
            Orb3()
            Text(answer,color=Color.White,modifier=Modifier.align(Alignment.CenterHorizontally))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){ listOf("Chat","Vision","Phone","Memory","Web","Automation").forEach { name->
                Surface(color=Color(0xFF101824),shape=RoundedCornerShape(10.dp),modifier=Modifier.padding(2.dp).clickable{tab=name}){Text(name,color=Color.Cyan,modifier=Modifier.padding(8.dp))}
            } }
            when(tab){
                "Chat"->{LazyColumn(Modifier.weight(1f)){items(chats){(u,a)->Text("$u: $a",color=Color.White,modifier=Modifier.padding(8.dp))}}}
                "Vision"->Text("Live Vision panel: camera permission and image-analysis backend integration pending.",color=Color.LightGray,modifier=Modifier.weight(1f))
                "Phone"->Column(Modifier.weight(1f)){Text("Quick launch",color=Color.White);listOf("Instagram","WhatsApp","YouTube","ChatGPT","Gemini","Facebook").forEach{Button(onClick={onOpenApp(it)}){Text("Open $it")}}}
                "Memory"->Text("Conversation memory is currently session-only; persistent memory module can be added.",color=Color.LightGray,modifier=Modifier.weight(1f))
                "Web"->Text("Web search opens browser search; live search API integration not configured.",color=Color.LightGray,modifier=Modifier.weight(1f))
                "Automation"->Text("Automation panel: user-approved tasks only; no unattended actions enabled.",color=Color.LightGray,modifier=Modifier.weight(1f))
                else->Spacer(Modifier.weight(1f))
            }
            Row(verticalAlignment=Alignment.CenterVertically){
                IconButton(onClick={val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN").putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);voice.launch(i)}){Text("🎙",fontSize=22.sp)}
                OutlinedTextField(text,{text=it},placeholder={Text("Ask MYRA…")},modifier=Modifier.weight(1f))
                Button(enabled=!busy,onClick={val q=text.trim();if(q.isNotEmpty()){chats.add("You" to q);text="";busy=true;scope.launch{val a=GeminiClient.ask(api,q);chats.add("MYRA" to a);answer=if(a.startsWith("Error"))a else "Ji boss";onSpeak(answer);busy=false}}}){Text(if(busy)"…" else "SEND")}
            }
        }
    }
}
@Composable fun Orb3(){
    val anim=rememberInfiniteTransition(label="orb");val scale by anim.animateFloat(.9f,1.1f,infiniteRepeatable(tween(1600),RepeatMode.Reverse),label="s")
    Canvas(Modifier.fillMaxWidth().height(190.dp)){val r=65.dp.toPx()*scale;drawCircle(Brush.radialGradient(listOf(Color(0xFFB8FFFF),Color(0xFF00B8D4),Color(0xFF4A148C),Color.Transparent),radius=r*1.6f),r*1.6f,center=center);drawCircle(Color.Cyan,r,center,style= androidx.compose.ui.graphics.drawscope.Stroke(3.dp.toPx()))}
}
