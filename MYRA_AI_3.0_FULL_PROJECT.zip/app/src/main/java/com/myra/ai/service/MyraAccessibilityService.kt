package com.myra.ai.service
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityService.GestureDescription
class MyraAccessibilityService:AccessibilityService(){
 override fun onAccessibilityEvent(event:AccessibilityEvent?) {}
 override fun onInterrupt() {}
 fun tap(x:Float,y:Float){if(Build.VERSION.SDK_INT>=24){val p=Path().apply{moveTo(x,y)};dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p,0,80)).build(),null,null)}}
 fun clickText(label:String):Boolean {val root=rootInActiveWindow?:return false;val nodes=root.findAccessibilityNodeInfosByText(label);return nodes.any{it.isClickable&&it.performAction(AccessibilityNodeInfo.ACTION_CLICK)}}
}
