package com.myra.ai.service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
class MyraForegroundService:Service(){
 override fun onCreate(){super.onCreate();if(Build.VERSION.SDK_INT>=26){val nm=getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel("myra_voice","MYRA Voice",NotificationManager.IMPORTANCE_LOW))}}
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
  val n=if(Build.VERSION.SDK_INT>=26)Notification.Builder(this,"myra_voice") else Notification.Builder(this)
  n.setContentTitle("MYRA AI 3.0").setContentText("Voice service running (wake-word engine integration required)").setSmallIcon(android.R.drawable.ic_btn_speak_now)
  startForeground(301,n.build());return START_STICKY
 }
 override fun onBind(intent:Intent?):IBinder?=null
}
